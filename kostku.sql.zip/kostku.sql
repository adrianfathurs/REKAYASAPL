-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2019 at 06:28 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kostku`
--

-- --------------------------------------------------------

--
-- Table structure for table `keuangan`
--

CREATE TABLE `keuangan` (
  `id_keuangan` int(11) NOT NULL,
  `via` varchar(64) NOT NULL,
  `bank` varchar(64) NOT NULL,
  `harga` int(11) NOT NULL,
  `id_kost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keuangan`
--

INSERT INTO `keuangan` (`id_keuangan`, `via`, `bank`, `harga`, `id_kost`) VALUES
(3, 'transfer', 'MANDIRI', 0, 5),
(4, 'tunai', 'BRI', 123200, 5),
(5, 'tunai', 'BRI', 123200, 5),
(6, 'transfer', 'BRI', 123200, 5),
(7, 'transfer', 'BCA', 123200, 5),
(8, 'transfer', 'BCA', 123200, 5),
(9, 'transfer', 'MANDIRI', 1800000, 7),
(10, 'transfer', 'BRI', 123200, 5),
(11, 'tunai', 'BRI', 123200, 5),
(12, 'tunai', 'BRI', 123200, 5),
(13, 'tunai', 'BRI', 123200, 5),
(14, 'transfer', 'BRI', 123200, 5),
(15, 'transfer', 'BCA', 123200, 5),
(16, 'transfer', 'BCA', 1800000, 7),
(17, 'tunai', 'BRI', 1800000, 7),
(18, 'transfer', 'BRI', 1800000, 7);

-- --------------------------------------------------------

--
-- Table structure for table `kost`
--

CREATE TABLE `kost` (
  `id_kost` int(11) NOT NULL,
  `nama_kost` varchar(64) NOT NULL,
  `alamat_kost` varchar(64) NOT NULL,
  `jenis_kost` varchar(64) NOT NULL,
  `harga_kost` int(11) NOT NULL,
  `deskripsi` varchar(320) NOT NULL,
  `gambar` varchar(64) NOT NULL,
  `id_pemilik` int(11) NOT NULL,
  `jumlah_kost` int(11) NOT NULL,
  `kota` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kost`
--

INSERT INTO `kost` (`id_kost`, `nama_kost`, `alamat_kost`, `jenis_kost`, `harga_kost`, `deskripsi`, `gambar`, `id_pemilik`, `jumlah_kost`, `kota`) VALUES
(5, 'GRIYA MUSLIMAH', 'jln', 'perempuan', 123200, 'kamar', 'kamarkost.jpg', 4, 2, 'YOGYAKARTA'),
(7, 'GRIYA Mocca', 'jln Garuda rt 11 rw 43 banjeng maguwoharjo depok sleman', 'laki-laki', 1800000, 'parkir luas', 'kost.jpg', 4, 6, 'SEMARANG'),
(9, 'Rockclusif', 'jkln sanata darma rt11', 'laki-laki', 600000, 'besar,ac,nyaman,kondisi bersih', 'kamarpi.jpg', 8, 5, 'YOGYAKARTA');

-- --------------------------------------------------------

--
-- Table structure for table `pemilik`
--

CREATE TABLE `pemilik` (
  `id_pemilik` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `no_telp` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemilik`
--

INSERT INTO `pemilik` (`id_pemilik`, `username`, `password`, `no_telp`) VALUES
(1, '', '', ''),
(3, 'Adrina', '123', '081227034973'),
(4, 'fathur', '123', '081227034973'),
(5, 'tono', '123', '0819988748'),
(6, 'joko', '123', '088399212'),
(8, 'rifki', '123', '0812232112');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `keuangan`
--
ALTER TABLE `keuangan`
  ADD PRIMARY KEY (`id_keuangan`),
  ADD KEY `id_kost` (`id_kost`);

--
-- Indexes for table `kost`
--
ALTER TABLE `kost`
  ADD PRIMARY KEY (`id_kost`),
  ADD KEY `fk_idpemilik` (`id_pemilik`);

--
-- Indexes for table `pemilik`
--
ALTER TABLE `pemilik`
  ADD PRIMARY KEY (`id_pemilik`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `keuangan`
--
ALTER TABLE `keuangan`
  MODIFY `id_keuangan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `kost`
--
ALTER TABLE `kost`
  MODIFY `id_kost` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pemilik`
--
ALTER TABLE `pemilik`
  MODIFY `id_pemilik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `keuangan`
--
ALTER TABLE `keuangan`
  ADD CONSTRAINT `keuangan_ibfk_1` FOREIGN KEY (`id_kost`) REFERENCES `kost` (`id_kost`);

--
-- Constraints for table `kost`
--
ALTER TABLE `kost`
  ADD CONSTRAINT `fk_idpemilik` FOREIGN KEY (`id_pemilik`) REFERENCES `pemilik` (`id_pemilik`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
